package com.cts.hms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cts.hms.model.PatientAppointment;
import com.cts.hms.model.SpecialistDetails;
import com.cts.hms.service.HospitalManagementServiceImpl;

@RestController
public class HospitalManagementController {
	@Autowired
	HospitalManagementServiceImpl hmsImpl;
	@RequestMapping(value = "${url.specialists}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@Cacheable("retSpecialistsCache")
	public List<SpecialistDetails> retriveSpecialists(@PathVariable ("hospitalName") String hospitalName,
			@PathVariable("specialistType") String specialistType){
		return hmsImpl.retriveSpecialist(hospitalName, specialistType);
	}
	
	@RequestMapping(value = "${url.appointment}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	@Cacheable("scheduleAppointmentCache")
	public PatientAppointment scheduleAppointment(@PathVariable("specialistName") String specialistName, 
			@PathVariable ("appointmentDay") String appointmentDay,
			@PathVariable("patientName") String patientName) {
		return hmsImpl.scheduleAppointment(specialistName, appointmentDay, patientName);
	}
	
	@RequestMapping(value = "${url.availableBeds}", method = RequestMethod.GET)
	public String fetchAdmissionAvailability(@PathVariable("hospitalName") String hospitalName) {
		return hmsImpl.fetchAdmissionAvailability(hospitalName);
	}

}
