package com.cts.hms.controller;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cts.hms.exception.ResultsNotFoundException;

@ControllerAdvice
public class ExceptionController {
	
	@ExceptionHandler(value=Exception.class)
	@ResponseBody
	public String handleException(ResultsNotFoundException exp) {
		return exp.getMessage();
	}

}
