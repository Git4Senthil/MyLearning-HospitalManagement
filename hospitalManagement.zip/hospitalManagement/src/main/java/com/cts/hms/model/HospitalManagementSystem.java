package com.cts.hms.model;

import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "hms")
public class HospitalManagementSystem {
	
	public HospitalManagementSystem() {
		super();
		// TODO Auto-generated constructor stub
	}

	public List<Hospital> hosp;

	public List<Hospital> getHosp() {
		return hosp;
	}

	public void setHosp(List<Hospital> hosp) {
		this.hosp = hosp;
	}
	

}
