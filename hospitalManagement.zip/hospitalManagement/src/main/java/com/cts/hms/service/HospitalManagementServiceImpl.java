package com.cts.hms.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.hms.constants.HmsConstants;
import com.cts.hms.exception.ResultsNotFoundException;
import com.cts.hms.model.Hospital;
import com.cts.hms.model.HospitalManagementSystem;
import com.cts.hms.model.PatientAppointment;
import com.cts.hms.model.PatientDetails;
import com.cts.hms.model.SpecialistDetails;

@Service
public class HospitalManagementServiceImpl implements HospitalManagementService {
	@Autowired
	HospitalManagementSystem hms;

	@Override
	public List<SpecialistDetails> retriveSpecialist(String hospitalName, String specialistType)
			throws ResultsNotFoundException {
		// TODO Auto-generated method stub
		List<SpecialistDetails> spDetailsList = new ArrayList<>();
		boolean isHospitalAvailable = false;
		if (hms != null) {
			for (Hospital hosp : hms.getHosp()) {
				if (hosp != null) {
					if (hospitalName.equalsIgnoreCase(hosp.getHospitalName())) {
						isHospitalAvailable = true;
						for (SpecialistDetails spDetails : hosp.getSpDetailsList()) {
							if (spDetails != null && specialistType.equalsIgnoreCase(spDetails.getType())) {
								spDetailsList.add(spDetails);
							}
						}
						if (spDetailsList.isEmpty()) {
							throw new ResultsNotFoundException(HmsConstants.NO_SUCH_SPECIALIST);
						}
					}
				}
			}
			if (!isHospitalAvailable) {
				throw new ResultsNotFoundException(HmsConstants.NO_HOSTPTIALS_FOUND);
			}
		}

		return spDetailsList;
	}

	@Override
	public PatientAppointment scheduleAppointment(String specialistName, String appointmentDay, String patientName)
			throws ResultsNotFoundException {
		// TODO Auto-generated method stub
		PatientAppointment appointmentDetails = null;
		boolean spNotAvailableonDay = false;
		if (hms != null) {
			for (Hospital hosp : hms.getHosp()) {
				if (hosp != null) {
					for (SpecialistDetails spDetails : hosp.getSpDetailsList()) {
						if (spDetails != null && specialistName.equalsIgnoreCase(spDetails.getName())) {
							if (spDetails.getAvailableDay().toLowerCase().contains(appointmentDay.toLowerCase())) {
								appointmentDetails = new PatientAppointment();
								appointmentDetails.setSpecialistName(spDetails.getName());
								appointmentDetails.setPatientName(patientName);
								appointmentDetails.setAppointmentDay(appointmentDay);
								appointmentDetails.setAppointmentTime(spDetails.getAvailableTime());
							} else {
								spNotAvailableonDay = true;
							}
						}
					}
				}
			}
			if (appointmentDetails == null) {
				if (spNotAvailableonDay) {
					throw new ResultsNotFoundException(HmsConstants.NO_SPECIALIST_SPECIFICDAY);
				} else {
					throw new ResultsNotFoundException(HmsConstants.NO_SPECILIST_SPEC_NAME);
				}
			}
		}

		return appointmentDetails;
	}

	@Override
	public String fetchAdmissionAvailability(String hospitalName) throws ResultsNotFoundException {
		boolean isHospitalAvailable = false;
		int bedsOccupied = 0;
		int bedsAvailableInt = 0;
		for (Hospital hosp : hms.getHosp()) {
			if (hosp != null && hospitalName.equalsIgnoreCase(hosp.getHospitalName())) {
				isHospitalAvailable = true;
				String bedsAvailable = hosp.getBedsAvailable();
				bedsAvailableInt = Integer.parseInt(bedsAvailable);
				if (!hosp.getPatient().isEmpty()) {
					for (PatientDetails patientDetails : hosp.getPatient()) {
						if (patientDetails != null && "admitted".equalsIgnoreCase(patientDetails.getPatientStatus())) {
							bedsOccupied++;
						}
					}
				}
				bedsAvailableInt -= bedsOccupied;
			}
		}
		if(isHospitalAvailable) {
			return HmsConstants.NO_OF_BEDS_AVAILABLE + bedsAvailableInt;
		} else {
			throw new ResultsNotFoundException(HmsConstants.NO_BED_DETAILS_FOUND);
		}
		
	}
}
