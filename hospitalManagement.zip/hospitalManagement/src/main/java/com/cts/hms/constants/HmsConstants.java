package com.cts.hms.constants;

import org.springframework.stereotype.Component;

@Component
public class HmsConstants {

	public static final String NO_BEDS_AVAIL="No Beds Available";
	public static final String NO_HOSTPTIALS_FOUND = "No Hospitals found for the spcified Hosptial ID.";
	public static final String NO_SPECIALIST_HOSP_ID="No specialist details found for the specified Hospital ID";
	public static final String NO_SUCH_SPECIALIST="No such specialist available";
	public static final String NO_SPECILAIST_HOSP_NAME="No specialist details found for the specified hospital name";
	public static final String NO_SPECIALIST_SPECIFICDAY="Specialist is not available on specified day";
	public static final String SPECIALIST_UNAVAILABLE="Currently specialist is not available";
	public static final String NO_SPECILIST_SPEC_NAME="No specialist details found for the specified Specialist name";
	public static final String NO_BED_DETAILS_FOUND="Bed details not found for the specified hospital name";
	
	public static final String NO_OF_BEDS_AVAILABLE = "Number of Beds Available is = ";
}
