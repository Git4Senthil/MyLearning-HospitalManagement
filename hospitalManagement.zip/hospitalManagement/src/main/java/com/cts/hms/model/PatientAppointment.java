package com.cts.hms.model;

/**
 * @author student
 *
 */
public class PatientAppointment {
	
	public PatientAppointment() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String specialistName;
	public String patientName;
	public String appointmentDay;
	public String appointmentTime;
	public String getSpecialistName() {
		return specialistName;
	}
	public void setSpecialistName(String specialistName) {
		this.specialistName = specialistName;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public String getAppointmentDay() {
		return appointmentDay;
	}
	public void setAppointmentDay(String appointmentDay) {
		this.appointmentDay = appointmentDay;
	}
	public String getAppointmentTime() {
		return appointmentTime;
	}
	public void setAppointmentTime(String appointmentTime) {
		this.appointmentTime = appointmentTime;
	}
	
	
	
}
