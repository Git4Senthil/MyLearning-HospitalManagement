package com.cts.hms.model;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "hms.hosp.patient")
public class PatientDetails {
	
	public PatientDetails(String patientId, String patientName, String patientStatus) {
		super();
		this.patientId = patientId;
		this.patientName = patientName;
		this.patientStatus = patientStatus;
	}
	public PatientDetails() {
		super();
	}
	public String patientId;
	public String patientName;
	public String patientStatus;
	public String getPatientId() {
		return patientId;
	}
	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public String getPatientStatus() {
		return patientStatus;
	}
	public void setPatientStatus(String patientStatus) {
		this.patientStatus = patientStatus;
	}	

}
