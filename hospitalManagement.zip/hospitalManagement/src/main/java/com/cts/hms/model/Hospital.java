package com.cts.hms.model;

import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "hms.hosp")
public class Hospital {
	
	public Hospital() {
		super();
		// TODO Auto-generated constructor stub
	}
	private String hospitalName;
	private String hospitalId;
	private String bedsAvailable;
	
	private List<SpecialistDetails> spdetailslist;
	
	private List<PatientDetails> patient;
	
	public String getHospitalName() {
		return hospitalName;
	}
	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}
	
	public String getHospitalId() {
		return hospitalId;
	}
	public void setHospitalId(String hospitalId) {
		this.hospitalId = hospitalId;
	}
	public String getBedsAvailable() {
		return bedsAvailable;
	}
	public void setBedsAvailable(String bedsAvailable) {
		this.bedsAvailable = bedsAvailable;
	}
	public List<SpecialistDetails> getSpdetailslist() {
		return spdetailslist;
	}
	public void setSpdetailslist(List<SpecialistDetails> spdetailslist) {
		this.spdetailslist = spdetailslist;
	}
	public List<SpecialistDetails> getSpDetailsList() {
		return spdetailslist;
	}
	public void setSpDetailsList(List<SpecialistDetails> spDetailsList) {
		this.spdetailslist = spDetailsList;
	}
	public List<PatientDetails> getPatient() {
		return patient;
	}
	public void setPatient(List<PatientDetails> patient) {
		this.patient = patient;
	}
}
