package com.cts.hms.service;

import java.util.List;

import com.cts.hms.exception.ResultsNotFoundException;
import com.cts.hms.model.PatientAppointment;
import com.cts.hms.model.SpecialistDetails;

public interface HospitalManagementService {

	public List<SpecialistDetails> retriveSpecialist(String hostpialName, String specialistType) throws ResultsNotFoundException;
	
	public PatientAppointment scheduleAppointment(String specialistName, String appointmentDay, String patientName) throws ResultsNotFoundException;
	
	public String fetchAdmissionAvailability(String hospitalName) throws ResultsNotFoundException;
}
