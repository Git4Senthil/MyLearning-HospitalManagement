package com.cts.hms;

import java.net.URI;
import java.net.URISyntaxException;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;

import com.cts.hms.constants.HmsConstants;
import com.cts.hms.model.SpecialistDetails;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment=WebEnvironment.RANDOM_PORT)
public class HospitalManagementControllerTest {
	
	@LocalServerPort
	int randomServerPort;
	
	@Value("${test.baseUrl}")
	String baseUrl;
	
	@Value("${url.specialists}")
	String serviceUrl;
	
	
	@Test
	public void testRetriveSpecialists() throws URISyntaxException{
		String hospitalName = "SuperSpecialityHospital";
		String specialistType = "Dentist";
		String baseAPIUrl = baseUrl+serviceUrl;
		baseAPIUrl = baseAPIUrl.replace("port", String.valueOf(randomServerPort));
		baseAPIUrl = baseAPIUrl.replace("{hospitalName}", hospitalName);
		baseAPIUrl = baseAPIUrl.replace("{specialistType}", specialistType);
		URI uri = new URI(baseAPIUrl);
		HttpHeaders headers = new HttpHeaders();
		headers.add("Accept", "application/json");
		headers.add("Content-Type", "application/json");
		HttpEntity request = new HttpEntity(headers);
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<SpecialistDetails[]> result = restTemplate.exchange(uri, HttpMethod.GET, request, SpecialistDetails[].class);
		Assert.assertEquals(200, result.getStatusCodeValue());
	}
	
	@Test
	public void testRetriveSpecialistsXML() throws URISyntaxException{
		String hospitalName = "SuperSpecialityHospital";
		String specialistType = "Dentist";
		String baseAPIUrl = baseUrl+serviceUrl;
		baseAPIUrl = baseAPIUrl.replace("port", String.valueOf(randomServerPort));
		baseAPIUrl = baseAPIUrl.replace("{hospitalName}", hospitalName);
		baseAPIUrl = baseAPIUrl.replace("{specialistType}", specialistType);
		URI uri = new URI(baseAPIUrl);
		HttpHeaders headers = new HttpHeaders();
		headers.add("Accept", "application/xml");
		headers.add("Content-Type", "application/xml");
		HttpEntity request = new HttpEntity(headers);
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<SpecialistDetails[]> result = restTemplate.exchange(uri, HttpMethod.GET, request, SpecialistDetails[].class);
		Assert.assertEquals(200, result.getStatusCodeValue());
	}
	
	@Test
	public void testRetriveSpecialistsInvalidHospitalName() throws URISyntaxException{
		String hospitalName = "SSHospital";
		String specialistType = "Dentist";
		String baseAPIUrl = baseUrl+serviceUrl;
		baseAPIUrl = baseAPIUrl.replace("port", String.valueOf(randomServerPort));
		baseAPIUrl = baseAPIUrl.replace("{hospitalName}", hospitalName);
		baseAPIUrl = baseAPIUrl.replace("{specialistType}", specialistType);
		URI uri = new URI(baseAPIUrl);
		HttpHeaders headers = new HttpHeaders();
		HttpEntity request = new HttpEntity(headers);
		headers.add("Accept", "application/json");
		headers.add("Content-Type", "application/json");
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<String> result = restTemplate.exchange(uri, HttpMethod.GET, request, String.class);
		Assert.assertEquals(200, result.getStatusCodeValue());
		Assert.assertEquals(HmsConstants.NO_HOSTPTIALS_FOUND, result.getBody());
	}
	
	@Test
	public void testRetriveSpecialistsInvalidSpecialistName() throws URISyntaxException{
		String hospitalName = "SuperSpecialityHospital";
		String specialistType = "Gynacologist";
		String baseAPIUrl = baseUrl+serviceUrl;
		baseAPIUrl = baseAPIUrl.replace("port", String.valueOf(randomServerPort));
		baseAPIUrl = baseAPIUrl.replace("{hospitalName}", hospitalName);
		baseAPIUrl = baseAPIUrl.replace("{specialistType}", specialistType);
		URI uri = new URI(baseAPIUrl);
		HttpHeaders headers = new HttpHeaders();
		HttpEntity request = new HttpEntity(headers);
		headers.add("Accept", "application/json");
		headers.add("Content-Type", "application/json");
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<String> result = restTemplate.exchange(uri, HttpMethod.GET, request, String.class);
		Assert.assertEquals(200, result.getStatusCodeValue());
		Assert.assertEquals(HmsConstants.NO_SUCH_SPECIALIST, result.getBody());
	}

}
